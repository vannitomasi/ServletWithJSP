--
-- NOTE:
--
-- File paths need to be edited. Search for $$PATH$$ and
-- replace it with the path to the directory containing
-- the extracted data files.
--
--
-- PostgreSQL database dump
--

-- Dumped from database version 13.2
-- Dumped by pg_dump version 13.2

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

DROP DATABASE boardgame_database;
--
-- Name: boardgame_database; Type: DATABASE; Schema: -; Owner: boardgame_user
--

CREATE DATABASE boardgame_database WITH TEMPLATE = template0 ENCODING = 'UTF8' LOCALE = 'English_United States.1252';


ALTER DATABASE boardgame_database OWNER TO boardgame_user;

\connect boardgame_database

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: boardgame_schema; Type: SCHEMA; Schema: -; Owner: boardgame_user
--

CREATE SCHEMA boardgame_schema;


ALTER SCHEMA boardgame_schema OWNER TO boardgame_user;

--
-- Name: adminpack; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS adminpack WITH SCHEMA pg_catalog;


--
-- Name: EXTENSION adminpack; Type: COMMENT; Schema: -; Owner: 
--

COMMENT ON EXTENSION adminpack IS 'administrative functions for PostgreSQL';


--
-- Name: zero_to_five_with_two_decimal; Type: DOMAIN; Schema: boardgame_schema; Owner: postgres
--

CREATE DOMAIN boardgame_schema.zero_to_five_with_two_decimal AS double precision
	CONSTRAINT "greater than 0" CHECK ((VALUE > (0)::double precision))
	CONSTRAINT "lesser than 5" CHECK ((VALUE <= (5)::double precision))
	CONSTRAINT "no more than two decimal" CHECK ((VALUE = (trunc((VALUE * (100)::double precision)) / (100)::double precision)));


ALTER DOMAIN boardgame_schema.zero_to_five_with_two_decimal OWNER TO postgres;

SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: boardgame_table; Type: TABLE; Schema: boardgame_schema; Owner: boardgame_user
--

CREATE TABLE boardgame_schema.boardgame_table (
    id integer NOT NULL,
    name text NOT NULL,
    release_date date,
    designer text,
    price money,
    complexity_weight boardgame_schema.zero_to_five_with_two_decimal
);


ALTER TABLE boardgame_schema.boardgame_table OWNER TO boardgame_user;

--
-- Name: boardgame_table_id_seq; Type: SEQUENCE; Schema: boardgame_schema; Owner: boardgame_user
--

CREATE SEQUENCE boardgame_schema.boardgame_table_id_seq
    AS integer
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1;


ALTER TABLE boardgame_schema.boardgame_table_id_seq OWNER TO boardgame_user;

--
-- Name: boardgame_table_id_seq; Type: SEQUENCE OWNED BY; Schema: boardgame_schema; Owner: boardgame_user
--

ALTER SEQUENCE boardgame_schema.boardgame_table_id_seq OWNED BY boardgame_schema.boardgame_table.id;


--
-- Name: boardgame_table id; Type: DEFAULT; Schema: boardgame_schema; Owner: boardgame_user
--

ALTER TABLE ONLY boardgame_schema.boardgame_table ALTER COLUMN id SET DEFAULT nextval('boardgame_schema.boardgame_table_id_seq'::regclass);


--
-- Data for Name: boardgame_table; Type: TABLE DATA; Schema: boardgame_schema; Owner: boardgame_user
--

COPY boardgame_schema.boardgame_table (id, name, release_date, designer, price, complexity_weight) FROM stdin;
\.
COPY boardgame_schema.boardgame_table (id, name, release_date, designer, price, complexity_weight) FROM '$$PATH$$/2993.dat';

--
-- Name: boardgame_table_id_seq; Type: SEQUENCE SET; Schema: boardgame_schema; Owner: boardgame_user
--

SELECT pg_catalog.setval('boardgame_schema.boardgame_table_id_seq', 2, true);


--
-- Name: boardgame_table boardgame_table_pk; Type: CONSTRAINT; Schema: boardgame_schema; Owner: boardgame_user
--

ALTER TABLE ONLY boardgame_schema.boardgame_table
    ADD CONSTRAINT boardgame_table_pk PRIMARY KEY (id);


--
-- Name: DATABASE boardgame_database; Type: ACL; Schema: -; Owner: boardgame_user
--

REVOKE ALL ON DATABASE boardgame_database FROM boardgame_user;
GRANT CREATE,CONNECT ON DATABASE boardgame_database TO boardgame_user;
GRANT TEMPORARY ON DATABASE boardgame_database TO boardgame_user WITH GRANT OPTION;


--
-- Name: SCHEMA boardgame_schema; Type: ACL; Schema: -; Owner: boardgame_user
--

REVOKE ALL ON SCHEMA boardgame_schema FROM boardgame_user;
GRANT ALL ON SCHEMA boardgame_schema TO boardgame_user WITH GRANT OPTION;


--
-- Name: TABLE boardgame_table; Type: ACL; Schema: boardgame_schema; Owner: boardgame_user
--

REVOKE ALL ON TABLE boardgame_schema.boardgame_table FROM boardgame_user;
GRANT ALL ON TABLE boardgame_schema.boardgame_table TO boardgame_user WITH GRANT OPTION;


--
-- PostgreSQL database dump complete
--

